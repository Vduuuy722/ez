package autoplace;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * Lightweight Auto Place for Litematica schematics.
 * Tuned for mobile/Amethyst: cached offsets, low scan frequency,
 * exact placement-angle probing and no Litematica compile dependency.
 */
public class AutoPlaceMod implements ClientModInitializer {
    private static final double REACH = 4.5D;
    private static final int PLACE_DELAY_TICKS = 2;
    private static final int SCAN_INTERVAL_TICKS = 4;
    private static final double MOVE_RESCAN_DISTANCE = 0.35D;
    private static final int MAX_CACHED_TARGETS = 4;

    private static KeyBinding toggleKey;
    private static boolean enabled;
    private static int placeCooldown;
    private static int scanCooldown;
    private static Vec3d lastPlayerEyePos;

    private static final List<BlockPos> OFFSETS = new ArrayList<>();
    private static final List<BlockPos> TARGET_CACHE = new ArrayList<>();

    private static final Set<Property<?>> IGNORE = Set.of(
            Properties.WATERLOGGED,
            Properties.POWERED,
            Properties.STAIR_SHAPE,
            Properties.NORTH,
            Properties.EAST,
            Properties.SOUTH,
            Properties.WEST
    );

    @Override
    public void onInitializeClient() {
        buildOffsets();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autoplace.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                KeyBinding.Category.create(Identifier.of("autoplace", "main"))
        ));

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("autoplace")
                        .executes(context -> {
                            toggle(context.getSource().getClient());
                            return 1;
                        })));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }


    private static void toggle(MinecraftClient mc) {
        enabled = !enabled;
        TARGET_CACHE.clear();
        lastPlayerEyePos = null;
        scanCooldown = 0;
        placeCooldown = 0;
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("Auto Place: " + (enabled ? "BẬT" : "TẮT")), true);
        }
    }

    private void tick(MinecraftClient mc) {
        while (toggleKey.wasPressed()) {
            toggle(mc);
        }

        if (!enabled || mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;

        if (placeCooldown > 0) {
            placeCooldown--;
            return;
        }

        World schematicWorld = getSchematicWorld();
        if (schematicWorld == null) return;

        boolean moved = hasPlayerMoved(mc.player);
        if (scanCooldown > 0 && !moved) {
            scanCooldown--;
        } else {
            rebuildTargetCache(mc, schematicWorld);
            scanCooldown = SCAN_INTERVAL_TICKS;
        }

        for (int i = 0; i < TARGET_CACHE.size(); i++) {
            BlockPos target = TARGET_CACHE.get(i);
            if (tryPlaceOne(mc, schematicWorld, target)) {
                placeCooldown = PLACE_DELAY_TICKS;
                TARGET_CACHE.remove(i);
                break;
            }
        }
    }

    private static void buildOffsets() {
        OFFSETS.clear();
        int radius = (int) Math.ceil(REACH);
        double reachSq = REACH * REACH + 1.0D;

        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    double d = x * x + y * y + z * z;
                    if (d <= reachSq) OFFSETS.add(new BlockPos(x, y, z));
                }
            }
        }

        OFFSETS.sort(Comparator.comparingDouble(p ->
                p.getX() * p.getX() + p.getY() * p.getY() + p.getZ() * p.getZ()));
    }

    private static boolean hasPlayerMoved(ClientPlayerEntity player) {
        Vec3d current = player.getEyePos();
        if (lastPlayerEyePos == null) {
            lastPlayerEyePos = current;
            return true;
        }

        double dx = current.x - lastPlayerEyePos.x;
        double dy = current.y - lastPlayerEyePos.y;
        double dz = current.z - lastPlayerEyePos.z;
        double distanceSq = dx * dx + dy * dy + dz * dz;
        if (distanceSq >= MOVE_RESCAN_DISTANCE * MOVE_RESCAN_DISTANCE) {
            lastPlayerEyePos = current;
            return true;
        }
        return false;
    }

    private static World getSchematicWorld() {
        try {
            Class<?> clazz = Class.forName("fi.dy.masa.litematica.world.SchematicWorldHandler");
            Method method = clazz.getMethod("getSchematicWorld");
            Object result = method.invoke(null);
            return result instanceof World ? (World) result : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static void rebuildTargetCache(MinecraftClient mc, World schematicWorld) {
        TARGET_CACHE.clear();
        ClientPlayerEntity player = mc.player;
        World world = mc.world;
        if (player == null || world == null) return;

        BlockPos base = player.getBlockPos();
        Vec3d eye = player.getEyePos();
        double reachSq = REACH * REACH;

        for (BlockPos offset : OFFSETS) {
            BlockPos pos = base.add(offset);
            Vec3d center = Vec3d.ofCenter(pos);
            if (center.squaredDistanceTo(eye) > reachSq) continue;

            BlockState want = schematicWorld.getBlockState(pos);
            if (want.isAir()) continue;

            BlockState have = world.getBlockState(pos);
            // Already correct: do not waste a placement attempt.
            if (matches(have, want)) continue;
            if (!have.isReplaceable()) continue;

            Item item = want.getBlock().asItem();
            if (item == Items.AIR) continue;
            if (findHotbar(player.getInventory(), item) < 0) continue;

            TARGET_CACHE.add(pos.toImmutable());
            if (TARGET_CACHE.size() >= MAX_CACHED_TARGETS) break;
        }
    }

    private static int findHotbar(PlayerInventory inventory, Item item) {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = inventory.getStack(slot);
            if (stack.isOf(item)) return slot;
        }
        return -1;
    }

    private static boolean tryPlaceOne(MinecraftClient mc, World schematicWorld, BlockPos pos) {
        ClientPlayerEntity player = mc.player;
        World world = mc.world;
        if (player == null || world == null) return false;

        BlockState want = schematicWorld.getBlockState(pos);
        if (want.isAir()) return false;

        BlockState current = world.getBlockState(pos);
        if (matches(current, want) || !current.isReplaceable()) return false;

        Item item = want.getBlock().asItem();
        if (item == Items.AIR) return false;

        int slot = findHotbar(player.getInventory(), item);
        if (slot < 0) return false;
        ItemStack stack = player.getInventory().getStack(slot);

        float originalYaw = player.getYaw();
        float originalPitch = player.getPitch();
        int originalSlot = player.getInventory().getSelectedSlot();

        // Candidate angles are ordered around the real view direction first,
        // then the four cardinal directions. This keeps mobile CPU usage low
        // while still handling stairs, logs, pistons, etc. reliably.
        float baseYaw = (float) Math.toDegrees(Math.atan2(
                Vec3d.ofCenter(pos).z - player.getZ(),
                Vec3d.ofCenter(pos).x - player.getX())) - 90.0F;
        float basePitch = pitchTo(player.getEyePos(), Vec3d.ofCenter(pos));

        float[] yawOffsets = {
                0F, 4F, -4F, 8F, -8F, 15F, -15F,
                90F, -90F, 180F
        };
        float[] pitchOffsets = {
                0F, 4F, -4F, 10F, -10F
        };

        try {
            for (Direction direction : placementDirections(pos, player, world)) {
                BlockPos neighbour = pos.offset(direction);
                BlockState neighbourState = world.getBlockState(neighbour);
                if (neighbourState.isAir() || neighbourState.isReplaceable()) continue;
                if (neighbourState.createScreenHandlerFactory(world, neighbour) != null) continue;

                Direction face = direction.getOpposite();
                Vec3d hitPos = faceHitPoint(neighbour, face, want);
                if (player.getEyePos().squaredDistanceTo(hitPos) > REACH * REACH) continue;

                BlockHitResult hit = new BlockHitResult(hitPos, face, neighbour, false);
                Float validYaw = null;
                Float validPitch = null;

                for (float po : pitchOffsets) {
                    for (float yo : yawOffsets) {
                        float yaw = normalizeYaw(baseYaw + yo);
                        float pitch = clampPitch(basePitch + po);
                        player.setYaw(yaw);
                        player.setPitch(pitch);

                        ItemPlacementContext context = new ItemPlacementContext(
                                player, Hand.MAIN_HAND, stack, hit);
                        if (!context.canPlace()) continue;

                        BlockState placed = want.getBlock().getPlacementState(context);
                        if (placed == null || !matches(placed, want)) continue;
                        if (!world.canPlace(placed, pos, ShapeContext.of(player))) continue;

                        validYaw = yaw;
                        validPitch = pitch;
                        break;
                    }
                    if (validYaw != null) break;
                }

                if (validYaw == null) continue;

                if (player.getInventory().getSelectedSlot() != slot) {
                    player.getInventory().setSelectedSlot(slot);
                    player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
                }

                player.setYaw(validYaw);
                player.setPitch(validPitch);
                player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                        validYaw, validPitch, player.isOnGround(), player.horizontalCollision));

                ActionResult result = mc.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
                if (result.isAccepted()) player.swingHand(Hand.MAIN_HAND);
                return result.isAccepted();
            }
            return false;
        } finally {
            player.setYaw(originalYaw);
            player.setPitch(originalPitch);
            if (player.getInventory().getSelectedSlot() != originalSlot) {
                player.getInventory().setSelectedSlot(originalSlot);
                player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(originalSlot));
            }
            player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                    originalYaw, originalPitch, player.isOnGround(), player.horizontalCollision));
        }
    }

    private static List<Direction> placementDirections(BlockPos pos, ClientPlayerEntity player, World world) {
        List<Direction> result = new ArrayList<>(6);
        Vec3d eye = player.getEyePos();
        for (Direction direction : Direction.values()) {
            BlockPos neighbour = pos.offset(direction);
            BlockState state = world.getBlockState(neighbour);
            if (state.isAir() || state.isReplaceable()) continue;
            result.add(direction);
        }
        result.sort(Comparator.comparingDouble(direction ->
                eye.squaredDistanceTo(Vec3d.ofCenter(pos.offset(direction)))));
        return result;
    }

    private static Vec3d faceHitPoint(BlockPos neighbour, Direction face, BlockState want) {
        double x = neighbour.getX() + 0.5D;
        double y = neighbour.getY() + 0.5D;
        double z = neighbour.getZ() + 0.5D;

        // Slightly inside the clicked face is more reliable than the exact
        // boundary on touch-based clients. For slabs, bias toward the desired half.
        if (face == Direction.WEST) x = neighbour.getX() + 0.501D;
        if (face == Direction.EAST) x = neighbour.getX() + 0.499D;
        if (face == Direction.NORTH) z = neighbour.getZ() + 0.501D;
        if (face == Direction.SOUTH) z = neighbour.getZ() + 0.499D;
        if (face == Direction.DOWN) y = neighbour.getY() + 0.501D;
        if (face == Direction.UP) y = neighbour.getY() + 0.499D;

        boolean top = want.contains(Properties.BLOCK_HALF)
                && want.get(Properties.BLOCK_HALF) == BlockHalf.TOP;
        if (want.contains(Properties.SLAB_TYPE)) {
            SlabType slab = want.get(Properties.SLAB_TYPE);
            top = slab == SlabType.TOP;
        }
        if (want.contains(Properties.BLOCK_HALF) || want.contains(Properties.SLAB_TYPE)) {
            if (face.getAxis().isHorizontal()) {
                y = neighbour.getY() + (top ? 0.74D : 0.26D);
            }
        }
        return new Vec3d(x, y, z);
    }

    private static float pitchTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        return (float) -Math.toDegrees(Math.atan2(dy, horizontal));
    }

    private static float normalizeYaw(float yaw) {
        yaw %= 360.0F;
        if (yaw >= 180.0F) yaw -= 360.0F;
        if (yaw < -180.0F) yaw += 360.0F;
        return yaw;
    }

    private static float clampPitch(float pitch) {
        return Math.max(-90.0F, Math.min(90.0F, pitch));
    }

    private static boolean matches(BlockState got, BlockState want) {
        if (got.getBlock() != want.getBlock()) return false;
        for (Property<?> property : want.getProperties()) {
            if (IGNORE.contains(property)) continue;
            if (!got.contains(property)) return false;
            if (!got.get(property).equals(want.get(property))) return false;
        }
        return true;
    }
}
