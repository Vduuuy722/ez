package autoplace;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class AutoPlaceAddon extends MeteorAddon {
    public static final Category CATEGORY = new Category("AutoPlace");

    @Override
    public void onInitialize() {
        Modules.get().add(new AutoPlaceMod());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "autoplace";
    }
}
