# AutoPlace — Gradle-ready build

## Build trên GitHub bằng điện thoại

1. Tạo một repository mới trên GitHub.
2. Upload toàn bộ file/thư mục trong ZIP này lên repository.
3. Vào tab **Actions**.
4. Chọn workflow **Build Fabric Mod**.
5. Nhấn **Run workflow**.
6. Chờ build hoàn tất.
7. Mở lần chạy vừa hoàn thành, kéo xuống **Artifacts** và tải `autoplace-jar`.

Project được cấu hình để build bằng Java 21 và Gradle 8.14.
