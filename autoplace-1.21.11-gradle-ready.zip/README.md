# AutoPlace Meteor Addon — Minecraft 1.21.11

Bản chuyển đổi từ AutoPlace Fabric mod sang **Meteor Client Addon**.

## Trong Meteor
- Category: **AutoPlace**
- Module: **Auto Place**
- Bật/tắt trực tiếp trong GUI Meteor.
- Không còn keybind K riêng và không còn `/autoplace`.

## Chức năng
- Dùng thế giới schematic của Litematica qua reflection, không cần compile dependency Litematica.
- Tìm block còn thiếu trong tầm 4.5 block.
- Tự tìm block tương ứng trong hotbar.
- Thử mặt đặt và góc nhìn trước khi đặt.
- Giữ nguyên logic mobile/Amethyst từ bản AutoPlace gốc.

## Yêu cầu
- Minecraft 1.21.11
- Fabric Loader 0.18.4+
- Meteor Client 1.21.11
- Litematica để đọc schematic
- Java 21
