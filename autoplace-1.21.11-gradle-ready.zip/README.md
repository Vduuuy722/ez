# AutoPlace Mobile — Minecraft 1.21.11

Client-side Fabric mod for Litematica schematic placement, tuned for mobile/Amethyst and iPhone-class hardware.

## Mobile controls
- In Amethyst/iOS chat, run `/autoplace` to toggle AutoPlace.
- A physical keyboard can also use **K**.

## Placement improvements
- Uses the actual target block state as the acceptance test.
- Skips blocks that already match the schematic.
- Chooses the nearest usable support face first.
- Computes a real look direction toward the click point.
- Tests a small ordered set of yaw/pitch offsets for orientation-sensitive blocks.
- Handles top/bottom slabs and block-half placement bias.
- Restores the player's camera and selected hotbar slot after each attempt.
- Uses eye-position movement checks instead of only block-position checks.
- Limits cached targets and scan frequency to reduce mobile CPU load.

## Runtime
- Minecraft: 1.21.11
- Fabric Loader: 0.18.1+
- Fabric API: 0.141.5+1.21.11
- Java: 21
- Litematica is detected at runtime through reflection; it is not bundled into this mod.

## Build
Run `./gradlew build` on a machine/environment with network access. The remapped mod JAR will be in `build/libs/`.
